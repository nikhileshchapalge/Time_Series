# TIU Andon Flask Dashboard

## New dashboard views
Each Pre-Machining, Machining and Post-Machining section now has three views:

1. **Tiles** - existing machine/OEE tiles.
2. **Production** - current-day production bar chart up to the current hour with target dotted line.
3. **Hourly** - 24-hour production matrix with the current hour highlighted.

The browser auto-rotates Tiles -> Production -> Hourly. Set `SCREEN_ROTATION_SECONDS` in `.env` if you want to change the rotation interval. The default is 15 seconds.

## Data architecture
SQL is read by the background worker every `DATA_REFRESH_SECONDS` (default 20 seconds). The worker calculates machine status/OEE/MES Bypass and production data, then atomically overwrites `data/andon_data.json`. The browser reads only the JSON/API snapshot.

## MES Bypass
`AT_MESBypassData` is checked by latest ID per WorkCenter. A record is active when `StartTime` is present and `EndTime` is NULL. Post-machining UC2 is mapped to database WorkCenter `UC02`.

## Removed
Reason Code and Acknowledge logic are not part of this Flask project.

## Run
1. Copy `.env.example` to `.env` and set SQL credentials.
2. Install dependencies: `pip install -r requirements.txt`
3. Run: `python run.py`
