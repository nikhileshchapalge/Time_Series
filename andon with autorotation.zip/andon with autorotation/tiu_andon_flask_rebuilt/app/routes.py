from functools import wraps
from flask import Blueprint, render_template, request, redirect, url_for, session, jsonify

from app.config import USERS
from app.services.data_cache import get_machines, get_machine, get_snapshot

main_bp = Blueprint("main", __name__)


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("logged_in"):
            return redirect(url_for("main.login"))
        return view(*args, **kwargs)
    return wrapped


@main_bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        if username in USERS and USERS[username]["password"] == password:
            session["logged_in"] = True
            session["username"] = username
            session["role"] = USERS[username]["role"]
            return redirect(url_for("main.index"))
    return render_template("login.html")


@main_bp.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("main.login"))


@main_bp.route("/")
@login_required
def index():
    section = request.args.get("section")
    machining_page = request.args.get("machining_page")
    machining_view = request.args.get("machining_view", "OP30")
    return render_template(
        "index.html",
        section=section,
        machining_page=machining_page,
        machining_view=machining_view,
        username=session.get("username"),
        role=session.get("role"),
    )


@main_bp.route("/main-menu")
@login_required
def main_menu():
    return redirect(url_for("main.index"))


@main_bp.route("/section/<section>")
@login_required
def section(section):
    section = section.upper()
    if section not in {"PRE_MACHINING", "MACHINING", "POST_MACHINING"}:
        return redirect(url_for("main.index"))
    return redirect(url_for("main.index", section=section))


@main_bp.route("/machining/<page>")
@login_required
def machining_page(page):
    page = page.upper()
    if page not in {"VMC1", "VMC2"}:
        return redirect(url_for("main.index", section="MACHINING"))
    return redirect(url_for("main.index", section="MACHINING", machining_page=page))


@main_bp.route("/machining/operation/<operation>")
@login_required
def machining_operation(operation):
    operation = operation.upper()
    if operation not in {"OP30", "OP40", "OP50"}:
        operation = "OP30"
    return redirect(url_for(
        "main.index",
        section="MACHINING",
        machining_page="VMC2",
        machining_view=operation,
    ))


@main_bp.route("/view/<view_mode>")
@login_required
def view_mode(view_mode):
    return redirect(url_for("main.index", section=request.args.get("section")))


@main_bp.route("/auto-rotate")
@login_required
def auto_rotate():
    return redirect(url_for("main.index", section=request.args.get("section")))


@main_bp.route("/machine/<section>/<machine_code>")
@login_required
def machine_detail(section, machine_code):
    machine = get_machine(section.upper(), machine_code)
    if not machine:
        return redirect(url_for("main.index", section=section.upper()))
    return render_template(
        "machine_detail.html",
        machine=machine,
        section=section.upper(),
    )


@main_bp.get("/api/machines/<section>")
@login_required
def machines_api(section):
    section = section.upper()
    machines = list(get_machines(section))
    page = request.args.get("page", "").upper()
    view = request.args.get("view", "OP30").upper()

    if section == "MACHINING":
        if page == "VMC1":
            machines = [m for m in machines if m["machine"].startswith(("OP_10", "OP_20"))]
        elif page == "VMC2":
            prefix = {"OP40": "OP_40", "OP50": "OP_50"}.get(view, "OP_30")
            machines = [m for m in machines if m["machine"].startswith(prefix)]
    else:
        machines = [m for m in machines if m["machine"] not in {"QLW01", "QLW02", "QLW03", "QALT"}]

    snapshot = get_snapshot()
    return jsonify({
        "section": section,
        "machines": machines,
        "updated_at": snapshot.get("updated_at"),
        "refresh_seconds": snapshot.get("refresh_seconds", 20),
        "status": snapshot.get("status"),
        "errors": snapshot.get("errors", {}),
    })


@main_bp.get("/api/andon-data")
@login_required
def andon_data_api():
    return jsonify(get_snapshot())


@main_bp.get("/api/production/<section>")
@login_required
def production_api(section):
    section = section.upper()
    snapshot = get_snapshot()
    production = snapshot.get("production", {}).get(section, {})
    return jsonify({
        "section": section,
        "production": production,
        "updated_at": snapshot.get("updated_at"),
        "refresh_seconds": snapshot.get("refresh_seconds", 20),
    })
