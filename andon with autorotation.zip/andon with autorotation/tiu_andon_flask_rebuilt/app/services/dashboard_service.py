from datetime import datetime
from pathlib import Path
import pandas as pd

from app.config import (
    machine_display, machining_display, post_machining_display,
    machine_queries, rework_queries, scrap_queries,
    post_machining_queries, post_machining_nok_queries,
    post_machining_rework_queries, targets, post_targets,
    graph_labels, DATA_REFRESH_SECONDS,
)
from app.services.db import get_connection, scalar


def shift_start_utc():
    return datetime.strptime(
        datetime.now().strftime("%Y-%m-%d") + " 01:00:00",
        "%Y-%m-%d %H:%M:%S",
    )


def shift_start_ist():
    return datetime.strptime(
        datetime.now().strftime("%Y-%m-%d") + " 06:30:00",
        "%Y-%m-%d %H:%M:%S",
    )


def get_elapsed_time(start_time):
    if start_time is None or pd.isna(start_time):
        return "00:00:00"
    seconds = max(0, int((datetime.now() - start_time).total_seconds()))
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    seconds %= 60
    return f"{hours:02}:{minutes:02}:{seconds:02}"


def format_status(status):
    status = str(status or "").strip().upper()
    if "MES BYPASS" in status:
        return "MES Bypass"
    if "OPERATIONAL_BREAKDOWN" in status:
        return "Operational Breakdown"
    if "BREAKDOWN" in status:
        return "Breakdown"
    return "Operational"


def get_status_color(status):
    status = format_status(status)
    return {
        "MES Bypass": "#7B1FA2",
        "Operational Breakdown": "#FF8C00",
        "Breakdown": "#D50000",
        "Operational": "#138A36",
    }.get(status, "#138A36")


def _empty_downtime_frame():
    return pd.DataFrame(columns=[
        "WorkCenter", "DowntimeStartTime_ist", "DowntimeEndTime_ist",
        "LastUpdateOn_ist", "Type",
    ])


def load_downtime_data(conn):
    cursor = conn.cursor()
    cursor.execute("""
        SELECT
            WorkCenter,
            DATEADD(MINUTE,330,DowntimeStartTime) AS DowntimeStartTime_ist,
            DATEADD(MINUTE,330,DowntimeEndTime) AS DowntimeEndTime_ist,
            DATEADD(MINUTE,330,LastUpdateOn) AS LastUpdateOn_ist,
            Type
        FROM AT_DowntimeData
        WHERE DowntimeStartTime >= ?
    """, shift_start_utc())
    rows = cursor.fetchall()
    return pd.DataFrame.from_records(
        rows, columns=[c[0] for c in cursor.description]
    ) if rows else _empty_downtime_frame()


def _latest_downtime_for_machine(downtime_df, machine):
    if downtime_df is None or downtime_df.empty:
        return None
    work = downtime_df["WorkCenter"].fillna("").astype(str)
    rows = downtime_df[work.str.contains(str(machine), regex=False, na=False)]
    if rows.empty:
        return None
    return rows.sort_values("DowntimeStartTime_ist", ascending=False).iloc[0]


def load_mes_bypass_data(conn):
    """Load the latest MES bypass record for PRE and POST machines in one SQL call.

    A bypass is active when StartTime is present and EndTime is NULL.
    Post-machine UC2 is stored as UC02 in AT_MESBypassData, so the configured
    post_machining_wc mapping is used.
    """
    from app.config import post_machining_wc

    mapping = {}
    for machine in machine_display:
        mapping[machine] = machine
    for machine, wc in post_machining_wc.items():
        mapping[machine] = wc

    workcenters = list(dict.fromkeys(mapping.values()))
    if not workcenters:
        return {}

    placeholders = ",".join("?" for _ in workcenters)
    cursor = conn.cursor()
    cursor.execute(f"""
        WITH Latest AS (
            SELECT
                WorkCenter,
                DATEADD(MINUTE,330,StartTime) AS StartTime_IST,
                DATEADD(MINUTE,330,EndTime) AS EndTime_IST,
                ID,
                ROW_NUMBER() OVER (
                    PARTITION BY WorkCenter
                    ORDER BY ID DESC
                ) AS rn
            FROM AT_MESBypassData
            WHERE WorkCenter IN ({placeholders})
        )
        SELECT WorkCenter, StartTime_IST, EndTime_IST, ID
        FROM Latest
        WHERE rn = 1
    """, *workcenters)

    by_wc = {}
    for row in cursor.fetchall():
        by_wc[str(row.WorkCenter).strip()] = row

    result = {}
    for machine, wc in mapping.items():
        row = by_wc.get(str(wc).strip())
        if row is not None:
            result[machine] = row
    return result


def _active_bypass(mes_row):
    if mes_row is None:
        return False
    start = getattr(mes_row, "StartTime_IST", None)
    end = getattr(mes_row, "EndTime_IST", None)
    return start is not None and not pd.isna(start) and (end is None or pd.isna(end))


def _status_for_machine(downtime_df, mes_map, machine, force_shift=False):
    shift = shift_start_ist()
    status = "Operational"
    since = shift.strftime("%d-%b-%y %H:%M:%S")
    runtime = get_elapsed_time(shift)

    # MES bypass has priority over downtime, matching the intended Andon state.
    mes_row = mes_map.get(machine)
    if _active_bypass(mes_row):
        status = "MES BYPASS"
        since = mes_row.StartTime_IST.strftime("%d-%b-%y %H:%M:%S")
        runtime = get_elapsed_time(mes_row.StartTime_IST)
    elif not force_shift:
        row = _latest_downtime_for_machine(downtime_df, machine)
        if row is not None:
            end = row.get("DowntimeEndTime_ist")
            start = row.get("DowntimeStartTime_ist")
            if pd.isna(end):
                dtype = str(row.get("Type", "")).upper()
                status = (
                    "BREAKDOWN"
                    if dtype == "BREAKDOWNTIME"
                    else "OPERATIONAL_BREAKDOWN"
                )
                if pd.notna(start):
                    since = start.strftime("%d-%b-%y %H:%M:%S")
                    runtime = get_elapsed_time(start)
            else:
                since = end.strftime("%d-%b-%y %H:%M:%S")
                runtime = get_elapsed_time(end)

    if machine == "BRZN_FX" and not _active_bypass(mes_row):
        since = shift.strftime("%d-%b-%Y %I:%M:%S %p")
        runtime = get_elapsed_time(shift)

    return format_status(status), since, runtime, get_status_color(status)


def calculate_availability(machine, conn=None, downtime_df=None):
    shift_ist = shift_start_ist()
    planned_minutes = max((datetime.now() - shift_ist).total_seconds() / 60, 0)
    if planned_minutes <= 0:
        return 0.0, 0.0

    if downtime_df is None:
        if conn is None:
            conn = get_connection()
            try:
                downtime_df = load_downtime_data(conn)
            finally:
                conn.close()
        else:
            downtime_df = load_downtime_data(conn)

    total_downtime = 0.0
    if downtime_df is not None and not downtime_df.empty:
        work = downtime_df["WorkCenter"].fillna("").astype(str)
        rows = downtime_df[
            work.str.contains(str(machine), regex=False, na=False)
            & downtime_df["Type"].fillna("").astype(str).str.lower().eq("breakdowntime")
        ]
        for _, row in rows.iterrows():
            start = row.get("DowntimeStartTime_ist")
            end = row.get("DowntimeEndTime_ist")
            if pd.notna(start):
                if pd.isna(end):
                    end = datetime.now()
                total_downtime += max(0, (end - start).total_seconds() / 60)

    runtime_minutes = max(planned_minutes - total_downtime, 0)
    availability = runtime_minutes / planned_minutes if planned_minutes else 0
    return availability, runtime_minutes


def calculate_productivity(ok_count, runtime_minutes, ideal_time_seconds=33):
    runtime_seconds = runtime_minutes * 60
    if runtime_seconds <= 0:
        return 0.0
    return round((ok_count * ideal_time_seconds) / runtime_seconds, 4)


def get_oee(machine_code, prod_count, rework_count, scrap_count, conn, downtime_df):
    availability, runtime_minutes = calculate_availability(
        machine_code, conn, downtime_df
    )
    productivity = calculate_productivity(prod_count, runtime_minutes, 33)
    total_count = prod_count + rework_count + scrap_count
    quality = prod_count / total_count if total_count else 0
    oee = availability * productivity * quality
    return {
        "availability": round(availability * 100, 2),
        "productivity": round(productivity * 100, 2),
        "quality": round(quality * 100, 2),
        "oee": round(oee * 100, 2),
    }


def get_machining_target(machine):
    workcenter = machine.replace("OP_", "OP-")
    if workcenter.startswith(("OP-10", "OP-20")):
        return 20
    if workcenter.startswith("OP-30") or workcenter.startswith("OP-40"):
        return 4
    if workcenter.startswith("OP-50"):
        return 30
    return 0


def get_machining_table(machine):
    wc = machine.replace("OP_", "OP-")
    if wc.startswith(("OP-10", "OP-20")):
        return "AT_VMC1Process"
    if wc.startswith(("OP-30", "OP-40", "OP-50")):
        return "AT_VMC2Process"
    return None


def get_machining_counts(machine, cursor, start):
    table = get_machining_table(machine)
    if not table:
        return 0, 0, 0
    wc = machine.replace("OP_", "OP-")
    cursor.execute(f"""
        SELECT
            ISNULL(SUM(CASE WHEN OutputScan=1 AND Active=1 AND IsRejected=0 THEN 1 ELSE 0 END),0) AS OK_Count,
            ISNULL(SUM(CASE WHEN OutputScan=1 AND Active=1 AND IsRejected=1 AND WipOrderNo LIKE '%R00%' THEN 1 ELSE 0 END),0) AS Rework_Count,
            ISNULL(SUM(CASE WHEN OutputScan=1 AND Active=1 AND IsRejected=1 THEN 1 ELSE 0 END),0) AS NOK_Count
        FROM {table}
        WHERE CreatedOn BETWEEN ? AND GETDATE()
          AND WorkCenter LIKE ?
    """, start, f"%{wc}%")
    row = cursor.fetchone()
    return int(row.OK_Count or 0), int(row.Rework_Count or 0), int(row.NOK_Count or 0)


def get_machining_oee(machine, prod_count, rework_count, nok_count, conn, downtime_df):
    availability, runtime_minutes = calculate_availability(machine, conn, downtime_df)
    target_per_hour = get_machining_target(machine)
    target_qty_runtime = target_per_hour * (runtime_minutes / 60)
    productivity = min(prod_count / target_qty_runtime, 1.0) if target_qty_runtime > 0 else 0
    total = prod_count + rework_count + nok_count
    quality = prod_count / total if total else 0
    oee = availability * productivity * quality
    return {
        "availability": round(availability * 100, 2),
        "productivity": round(productivity * 100, 2),
        "quality": round(quality * 100, 2),
        "oee": round(oee * 100, 2),
    }


def _scalar_count(cursor, query, start):
    return scalar(cursor, query, start) if query else 0


def load_machine_data(conn=None, downtime_df=None, mes_map=None):
    own = conn is None
    if own:
        conn = get_connection()
    try:
        if downtime_df is None:
            downtime_df = load_downtime_data(conn)
        if mes_map is None:
            mes_map = load_mes_bypass_data(conn)

        cursor = conn.cursor()
        start = shift_start_utc()
        shift = shift_start_ist()
        elapsed_hours = max((datetime.now() - shift).total_seconds() / 3600, 0)
        machines = []

        for machine in machine_display:
            status, since, runtime, status_color = _status_for_machine(
                downtime_df, mes_map, machine
            )
            prod = _scalar_count(cursor, machine_queries.get(machine), start)
            rw = _scalar_count(cursor, rework_queries.get(machine), start)
            nok = _scalar_count(cursor, scrap_queries.get(machine), start)
            target_qty = int(targets.get(machine, 0) * elapsed_hours)
            count_color = "#D50000" if prod < target_qty else "#138A36"
            oee = get_oee(machine, prod, rw, nok, conn, downtime_df)
            machines.append({
                "machine": machine,
                "machine_section": "PRE_MACHINING",
                "display_name": machine_display.get(machine, machine),
                "status": status,
                "status_color": status_color,
                "since": since,
                "runtime": runtime,
                "prod_count": prod,
                "part_count_color": count_color,
                "target_label": target_qty,
                "arrow": "▼" if prod < target_qty else "▲",
                "rw_count": rw,
                "rework_count": rw,
                "scrap_count": nok,
                "availability": oee["availability"],
                "productivity": oee["productivity"],
                "quality": oee["quality"],
                "oee": oee["oee"],
                "matrix_value": 100,
            })
        return machines
    finally:
        if own:
            conn.close()


def load_machining_data(conn=None, downtime_df=None, mes_map=None):
    own = conn is None
    if own:
        conn = get_connection()
    try:
        if downtime_df is None:
            downtime_df = load_downtime_data(conn)
        if mes_map is None:
            mes_map = load_mes_bypass_data(conn)

        cursor = conn.cursor()
        start = shift_start_utc()
        shift = shift_start_ist()
        elapsed_hours = max((datetime.now() - shift).total_seconds() / 3600, 0)
        machines = []

        for machine, display_name in machining_display.items():
            prod, rw, nok = get_machining_counts(machine, cursor, start)
            target = get_machining_target(machine)
            target_qty = int(target * elapsed_hours)
            color = "#D50000" if prod < target_qty else "#138A36"
            status, since, runtime, status_color = _status_for_machine(
                downtime_df, mes_map, machine, force_shift=True
            )
            oee = get_machining_oee(machine, prod, rw, nok, conn, downtime_df)
            machines.append({
                "machine": machine,
                "machine_section": "MACHINING",
                "display_name": display_name,
                "prod_count": prod,
                "scrap_count": nok,
                "status": status,
                "status_color": status_color,
                "since": since,
                "runtime": runtime,
                "target_label": target_qty,
                "part_count_color": color,
                "arrow": "▼" if prod < target_qty else "▲",
                "rw_count": rw,
                "rework_count": rw,
                "availability": oee["availability"],
                "productivity": oee["productivity"],
                "quality": oee["quality"],
                "oee": oee["oee"],
                "matrix_value": target,
            })
        return machines
    finally:
        if own:
            conn.close()


def load_post_machining_data(conn=None, downtime_df=None, mes_map=None):
    own = conn is None
    if own:
        conn = get_connection()
    try:
        if downtime_df is None:
            downtime_df = load_downtime_data(conn)
        if mes_map is None:
            mes_map = load_mes_bypass_data(conn)

        cursor = conn.cursor()
        start = shift_start_utc()
        shift = shift_start_ist()
        elapsed_hours = max((datetime.now() - shift).total_seconds() / 3600, 0)
        machines = []

        for machine, display_name in post_machining_display.items():
            ok = _scalar_count(cursor, post_machining_queries.get(machine), start)
            nok = _scalar_count(cursor, post_machining_nok_queries.get(machine), start)
            rw = _scalar_count(cursor, post_machining_rework_queries.get(machine), start)
            status, since, runtime, status_color = _status_for_machine(
                downtime_df, mes_map, machine
            )
            target_qty = int(post_targets.get(machine, 0) * elapsed_hours)
            color = "#D50000" if ok < target_qty else "#138A36"
            oee = get_oee(machine, ok, rw, nok, conn, downtime_df)
            machines.append({
                "machine": machine,
                "machine_section": "POST_MACHINING",
                "display_name": display_name,
                "status": status,
                "status_color": status_color,
                "since": since,
                "runtime": runtime,
                "prod_count": ok,
                "rw_count": rw,
                "rework_count": rw,
                "scrap_count": nok,
                "target_label": target_qty,
                "part_count_color": color,
                "arrow": "▼" if ok < target_qty else "▲",
                "availability": oee["availability"],
                "productivity": oee["productivity"],
                "quality": oee["quality"],
                "oee": oee["oee"],
                "matrix_value": 100,
            })
        return machines
    finally:
        if own:
            conn.close()



HOUR_SLOTS = [
    "06:30-07:30","07:30-08:30","08:30-09:30","09:30-10:30",
    "10:30-11:30","11:30-12:30","12:30-13:30","13:30-14:30",
    "14:30-15:30","15:30-16:30","16:30-17:30","17:30-18:30",
    "18:30-19:30","19:30-20:30","20:30-21:30","21:30-22:30",
    "22:30-23:30","23:30-00:30","00:30-01:30","01:30-02:30",
    "02:30-03:30","03:30-04:30","04:30-05:30","05:30-06:30",
]
SLOT_HOURS = [6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,0,1,2,3,4,5]


def _current_slot():
    now = datetime.now()
    hour = now.hour
    idx = SLOT_HOURS.index(hour)
    return HOUR_SLOTS[idx]


def _hourly_query(cursor, query, start):
    if not query:
        return {}
    cursor.execute(query, start)
    out = {h: 0 for h in SLOT_HOURS}
    for row in cursor.fetchall():
        hr = int(getattr(row, "Hr", 0))
        qty = int(getattr(row, "Qty", 0) or 0)
        if hr in out:
            out[hr] = qty
    return out


def _group_query(table, where):
    return f"""
        SELECT DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn)) AS Hr,
               ISNULL(SUM(PartQuantity),0) AS Qty
        FROM {table}
        WHERE CreatedOn BETWEEN ? AND GETDATE()
          AND {where}
        GROUP BY DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn))
        ORDER BY Hr
    """


def _pre_hourly_queries():
    # Same source tables/filters as machine_queries, but grouped by hour.
    return {
        "UC01_IP": _group_query("AT_Ultrasonic1process", "OutputScan=1 AND Parts='M4ACN0111M00'"),
        "SPFL_IP": _group_query("AT_SprayFluxingProcess", "OutputScan=1 AND UndoFlag=0 AND Parts='M4ACN0111M00'"),
        "CLNC": _group_query("AT_Clinchingprocess", "OutputScan=1 AND Active=1"),
        "RSHP": _group_query("AT_Reshapingprocess", "OutputScan=1"),
        "SHBL": _group_query("AT_ShotBlastingprocess", "OutputScan=1"),
        "ALT1_01": _group_query("AT_ALT1_Process", "OutputScan=1 AND IsRejected=0 AND Active=1"),
        "BRZN_FX": _group_query("AT_BrazingProcess", "OutputScan=1 AND Active=1"),
        "QALT": """
            SELECT DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn)) AS Hr,
                   ISNULL(COUNT(Quantity),0) AS Qty
            FROM AT_QUALITY_SAMPLE
            WHERE WorkCenter LIKE 'ALT1%' AND Status='QAOK'
              AND CreatedOn BETWEEN ? AND GETDATE()
            GROUP BY DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn))
            ORDER BY Hr
        """,
    }


def _laser_hourly_query(wc):
    return f"""
        ;WITH EquipMap AS (
            SELECT W.WorkCenter, UC.Attribute_ AS EquipmentName
            FROM WORK_CENTER W
            JOIN UNIT_CHARACTERISTIC UC ON UC.UnitID=W.UnitID
              AND UC.Characteristic='OutputStation'
            WHERE W.WorkCenter='{wc}'
        )
        SELECT DATEPART(HOUR, DATEADD(MINUTE,330,cp.CreatedOn)) AS Hr,
               COUNT(*) AS Qty
        FROM AT_LaserWeldingPLCData cp
        JOIN EQUIPMENT E ON E.ID=cp.EquipmentID
        JOIN EquipMap em ON em.WorkCenter='{wc}' AND E.Equipment=em.EquipmentName
        WHERE cp.CreatedOn BETWEEN ? AND GETDATE()
        GROUP BY DATEPART(HOUR, DATEADD(MINUTE,330,cp.CreatedOn))
        ORDER BY Hr
    """


def _disposition_hourly_query():
    return """
        SELECT DATEPART(HOUR, DATEADD(MINUTE,330,D.CreatedOn)) AS Hr,
               ISNULL(SUM(D.Quantity),0) AS Qty
        FROM DISPOSITION D
        WHERE D.OprSequenceNo=15 AND D.Status IN (14,4)
          AND D.CreatedOn BETWEEN ? AND GETDATE()
        GROUP BY DATEPART(HOUR, DATEADD(MINUTE,330,D.CreatedOn))
        ORDER BY Hr
    """


def _post_hourly_queries():
    return {
        "SG": _group_query("AT_ColdPlateLoadingProcess", "Active=1 AND OutputScan=1 AND LEN(ISNULL(SerialNo,''))>0 AND ISNULL(IsRejected,0)<>1"),
        "UC2": _group_query("AT_Ultrasonic2process", "Active=1 AND LEN(ISNULL(SerialNo,''))>0 AND ISNULL(IsRejected,0)<>1"),
        "EOL": """
            SELECT DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn)) AS Hr,
                   COUNT(DISTINCT SerialNumber) AS Qty
            FROM AT_TestingLineProcess
            WHERE Active=1 AND LEN(ISNULL(SerialNumber,''))>0
              AND LEN(ISNULL(LM2SerialNumber,''))>0 AND LEN(ISNULL(WipOrderNo,''))>0
              AND CreatedOn BETWEEN ? AND GETDATE()
            GROUP BY DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn)) ORDER BY Hr
        """,
        "PACK": """
            SELECT DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn)) AS Hr,
                   COUNT(ID) AS Qty
            FROM AT_PackagingProcess
            WHERE SerialLabelStatus=1 AND Active=1
              AND CreatedOn BETWEEN ? AND GETDATE()
            GROUP BY DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn)) ORDER BY Hr
        """,
    }


def load_production_data(conn):
    """Load current-day and hourly production in the same JSON refresh cycle."""
    start = shift_start_utc()
    cursor = conn.cursor()
    sections = {}

    pre = []
    pre_queries = _pre_hourly_queries()
    for machine in machine_display:
        label = graph_labels.get(machine, machine)
        if machine in ("LW01", "LW02", "LW03"):
            hourly = _hourly_query(cursor, _laser_hourly_query(machine), start)
        elif machine == "QLW01":
            hourly = _hourly_query(cursor, _laser_hourly_query("LW01"), start)
        elif machine == "QLW02":
            hourly = _hourly_query(cursor, _laser_hourly_query("LW02"), start)
        elif machine == "QLW03":
            hourly = _hourly_query(cursor, _disposition_hourly_query(), start)
        else:
            hourly = _hourly_query(cursor, pre_queries.get(machine), start)
        target = targets.get(machine, 0)
        pre.append({
            "machine": machine, "label": label,
            "actual": sum(hourly.values()), "target_per_hour": target,
            "target_till_hour": target * (max(0, len(HOUR_SLOTS[:SLOT_HOURS.index(datetime.now().hour)+1]))),
            "hourly": [hourly[h] for h in SLOT_HOURS],
            "kind": "OK" if machine.startswith("QLW") or machine == "QALT" else "A-JPH",
        })
    sections["PRE_MACHINING"] = _production_section(pre)

    post = []
    for machine, query in _post_hourly_queries().items():
        hourly = _hourly_query(cursor, query, start)
        target = post_targets.get(machine, 0)
        post.append({
            "machine": machine, "label": post_machining_display.get(machine, machine),
            "actual": sum(hourly.values()), "target_per_hour": target,
            "target_till_hour": target * (SLOT_HOURS.index(datetime.now().hour)+1),
            "hourly": [hourly[h] for h in SLOT_HOURS], "kind": "A-JPH",
        })
    sections["POST_MACHINING"] = _production_section(post)

    # Machining: use the same VMC tables already used for tile counts.
    machining = []
    for machine, display in machining_display.items():
        table = get_machining_table(machine)
        if not table:
            continue
        wc = machine.replace("OP_", "OP-")
        query = f"""
            SELECT DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn)) AS Hr,
                   ISNULL(SUM(CASE WHEN OutputScan=1 AND Active=1 AND IsRejected=0 THEN 1 ELSE 0 END),0) AS Qty
            FROM {table}
            WHERE CreatedOn BETWEEN ? AND GETDATE() AND WorkCenter LIKE '%{wc}%'
            GROUP BY DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn)) ORDER BY Hr
        """
        hourly = _hourly_query(cursor, query, start) if table else {h:0 for h in SLOT_HOURS}
        target = get_machining_target(machine)
        machining.append({
            "machine": machine, "label": display, "actual": sum(hourly.values()),
            "target_per_hour": target, "target_till_hour": target*(SLOT_HOURS.index(datetime.now().hour)+1),
            "hourly": [hourly[h] for h in SLOT_HOURS], "kind":"A-JPH"
        })
    sections["MACHINING"] = _production_section(machining)
    return sections


def _production_section(items):
    now_hour = datetime.now().hour
    current_index = SLOT_HOURS.index(now_hour)
    for item in items:
        item["actual_till_hour"] = sum(item["hourly"][:current_index+1])
        item["target_till_hour"] = item["target_per_hour"] * (current_index+1)
    return {
        "hour_slots": HOUR_SLOTS,
        "current_slot": HOUR_SLOTS[current_index],
        "current_index": current_index,
        "items": items,
        "updated_at": datetime.now().astimezone().isoformat(timespec="seconds"),
    }


def get_machines(section):
    # Compatibility helper. Normal dashboard routes use the JSON cache.
    conn = get_connection()
    try:
        downtime = load_downtime_data(conn)
        mes = load_mes_bypass_data(conn)
        section = section.upper()
        if section == "PRE_MACHINING":
            return load_machine_data(conn, downtime, mes)
        if section == "MACHINING":
            return load_machining_data(conn, downtime, mes)
        if section == "POST_MACHINING":
            return load_post_machining_data(conn, downtime, mes)
        return []
    finally:
        conn.close()


def get_machine(section, machine_code):
    code = str(machine_code).upper()
    for machine in get_machines(section):
        if str(machine.get("machine", "")).upper() == code:
            return machine
    return None
